package com.sz.rxjava2.myrxjava2;


public interface MyObservableOnSubscribe<T> {
	void subscribe(MyEmitter<T> var1);
}
