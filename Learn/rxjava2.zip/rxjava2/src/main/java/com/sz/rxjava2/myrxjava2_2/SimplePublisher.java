package com.sz.rxjava2.myrxjava2_2;

public interface SimplePublisher<T> {
	void subscribe(SimpleSubscriber<? super T> var1);
}
