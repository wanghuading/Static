package com.sz.rxjava2.myrxjava2;

public interface MyDisposable {

	void dispose();

	boolean isDisposed();
}
