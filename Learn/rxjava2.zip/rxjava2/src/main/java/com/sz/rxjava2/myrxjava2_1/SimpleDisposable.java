package com.sz.rxjava2.myrxjava2_1;

public interface SimpleDisposable {
	void dispose();
	
	boolean isDisposed();
}
