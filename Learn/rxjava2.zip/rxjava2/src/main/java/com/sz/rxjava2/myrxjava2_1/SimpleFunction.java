package com.sz.rxjava2.myrxjava2_1;

public interface SimpleFunction<T, R> {
    R apply(T var1);
}
